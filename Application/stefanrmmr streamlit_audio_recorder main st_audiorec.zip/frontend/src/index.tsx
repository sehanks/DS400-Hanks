import React from "react"
import ReactDOM from "react-dom"
import StAudioRec from "./StreamlitAudioRecorder"

ReactDOM.render(
  <React.StrictMode>
    <StAudioRec />
  </React.StrictMode>,
  document.getElementById("root")
)
